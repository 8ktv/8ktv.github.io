## Changelog
# 3.1.5
- tried to fix that one error

# 3.1.4
- Improved ASEL™️ (Anticheat Science Experimentation Lab)

# 3.1.3
- Updated updater

# 3.1.2
- Code patches for upcoming update

# 3.1.1
- Code patches for teleporting ig idk

# 3.1.0
- Found bypasses that hollyn can learn off of, Tanuki feel free to copy paste or hop on bandwagon.

# 2.1.2
- Changed how the updated detects updates (Now does it in seconds for more responsiveness)

# 2.1.1
- Code Cleanup from 2.1.1 nothing much changed

# 2.1.0
- Rewrote the whole updater and gave the thing a animation cuz im cool

# 2.0.7
- Started to be awesome and update the way on how we update automatically into one dll package
